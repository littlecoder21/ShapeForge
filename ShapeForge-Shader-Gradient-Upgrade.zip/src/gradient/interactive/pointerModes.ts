export const POINTER_MODES = [
  { id: 'attract', label: 'Attract', group: 'Essentials', description: 'Pulls the gradient field toward the pointer.' },
  { id: 'repel', label: 'Repel', group: 'Essentials', description: 'Pushes the gradient field away from the pointer.' },
  { id: 'swirl', label: 'Swirl', group: 'Essentials', description: 'Rotates nearby color contours around the pointer.' },
  { id: 'glow', label: 'Glow light', group: 'Essentials', description: 'Adds a soft interaction-colored light under the pointer.' },
  { id: 'drag', label: 'Drag field', group: 'Essentials', description: 'Drags the color field along with the pointer.' },
  { id: 'wave', label: 'Wave', group: 'Essentials', description: 'Sends moving wave bands outward from the pointer.' },
  { id: 'orbit', label: 'Orbit', group: 'Essentials', description: 'Combines orbiting motion with a gentle inward pull.' },
  { id: 'magnet', label: 'Magnet', group: 'Essentials', description: 'Strongly attracts the field with a rippling magnetic edge.' },
  { id: 'ripple', label: 'Cursor ripple', group: 'Essentials', description: 'Continuously emits a moving ring from the pointer.' },
  { id: 'pulse', label: 'Pulse', group: 'Essentials', description: 'Pulses a focused ring at the pointer position.' },
  { id: 'trail', label: 'Motion trail', group: 'Essentials', description: 'Leaves a fading streak along the pointer movement path.' },
  { id: 'spotlight', label: 'Spotlight', group: 'Essentials', description: 'Illuminates a tighter area around the pointer.' },
  { id: 'hue', label: 'Hue shift', group: 'Essentials', description: 'Shifts through the current layer palette around the pointer.' },
  { id: 'chromatic-flow', label: 'Chromatic flow', group: 'Color & spectrum', description: 'Sweeps interaction colors through a flowing field.' },
  { id: 'prism-ripple', label: 'Prism ripple', group: 'Color & spectrum', description: 'Refracts the multicolor interaction palette into radial ripples.' },
  { id: 'spectral-orbit', label: 'Spectral orbit', group: 'Color & spectrum', description: 'Orbits palette colors around the pointer in a rotating halo.' },
  { id: 'chroma-wave', label: 'Chroma wave', group: 'Color & spectrum', description: 'Bends the color field with a moving chromatic wave.' },
  { id: 'neon-pulse', label: 'Neon pulse', group: 'Color & spectrum', description: 'Pulses a saturated, multicolor neon ring.' },
  { id: 'color-chase', label: 'Color chase', group: 'Color & spectrum', description: 'Cycles interaction colors along the pointer path.' },
  { id: 'aurora-trail', label: 'Aurora trail', group: 'Color & spectrum', description: 'Leaves a broad, shifting aurora wake.' },
  { id: 'iridescent-sheen', label: 'Iridescent sheen', group: 'Color & spectrum', description: 'Shifts a spectrum sheen across the pointer field.' },
  { id: 'spectrum-bloom', label: 'Spectrum bloom', group: 'Color & spectrum', description: 'Expands a soft bloom that cycles through interaction colors.' },
  { id: 'rainbow-turbulence', label: 'Rainbow turbulence', group: 'Color & spectrum', description: 'Injects swirling spectrum turbulence into the gradient.' },
  { id: 'vortex-pull', label: 'Vortex pull', group: 'Field & forces', description: 'Pulls the field inward while twisting it into a vortex.' },
  { id: 'vortex-push', label: 'Vortex push', group: 'Field & forces', description: 'Pushes the field outward with a rotating vortex edge.' },
  { id: 'spiral-galaxy', label: 'Spiral galaxy', group: 'Field & forces', description: 'Bends colors into a multi-arm spiral around the pointer.' },
  { id: 'whirlpool', label: 'Whirlpool', group: 'Field & forces', description: 'Swirls a deep, water-like field toward the pointer.' },
  { id: 'tornado', label: 'Tornado', group: 'Field & forces', description: 'Funnels the field into a narrow rotating column.' },
  { id: 'orbital-sling', label: 'Orbital sling', group: 'Field & forces', description: 'Slings nearby colors into a fast orbital path.' },
  { id: 'gravity-well', label: 'Gravity well', group: 'Field & forces', description: 'Compresses the gradient into a soft gravitational lens.' },
  { id: 'magnetic-flux', label: 'Magnetic flux', group: 'Field & forces', description: 'Draws curved magnetic flux lines through the field.' },
  { id: 'lens-distort', label: 'Lens distort', group: 'Field & forces', description: 'Magnifies and bends the gradient below the pointer.' },
  { id: 'spacetime-warp', label: 'Spacetime warp', group: 'Field & forces', description: 'Warps the field into a broad relativistic wave.' },
  { id: 'shockwave', label: 'Shockwave', group: 'Waves & pulses', description: 'Sends a sharp expanding shockwave through the gradient.' },
  { id: 'concentric-rings', label: 'Concentric rings', group: 'Waves & pulses', description: 'Draws several interference rings around the pointer.' },
  { id: 'radial-burst', label: 'Radial burst', group: 'Waves & pulses', description: 'Radiates a burst of color from the pointer position.' },
  { id: 'ripple-cascade', label: 'Ripple cascade', group: 'Waves & pulses', description: 'Stacks multiple offset ripple fronts.' },
  { id: 'sonar-ping', label: 'Sonar ping', group: 'Waves & pulses', description: 'Emits a bright sonar sweep with a fading echo.' },
  { id: 'water-drop', label: 'Water drop', group: 'Waves & pulses', description: 'Refracts the field like a drop falling into water.' },
  { id: 'wavefront', label: 'Wavefront', group: 'Waves & pulses', description: 'Pushes a broad curved wavefront across the field.' },
  { id: 'interference', label: 'Interference', group: 'Waves & pulses', description: 'Layers crossing wave patterns into an interference field.' },
  { id: 'heartbeat', label: 'Heartbeat', group: 'Waves & pulses', description: 'Pulses the color field in a double-beat rhythm.' },
  { id: 'pulse-grid', label: 'Pulse grid', group: 'Waves & pulses', description: 'Creates a responsive grid of pulsing color cells.' },
  { id: 'spotlight-sweep', label: 'Spotlight sweep', group: 'Light & optics', description: 'Sweeps a narrow colored beam along pointer motion.' },
  { id: 'laser-scan', label: 'Laser scan', group: 'Light & optics', description: 'Scans a bright line across the gradient field.' },
  { id: 'flare-burst', label: 'Flare burst', group: 'Light & optics', description: 'Adds a bright lens flare with radial streaks.' },
  { id: 'soft-focus', label: 'Soft focus', group: 'Light & optics', description: 'Softens colors into a wide, defocused light field.' },
  { id: 'prism-light', label: 'Prism light', group: 'Light & optics', description: 'Splits interaction light into prismatic color bands.' },
  { id: 'caustic-shimmer', label: 'Caustic shimmer', group: 'Light & optics', description: 'Creates shifting caustic highlights around the pointer.' },
  { id: 'specular-glint', label: 'Specular glint', group: 'Light & optics', description: 'Tracks a crisp specular glint across the gradient.' },
  { id: 'shadow-well', label: 'Shadow well', group: 'Light & optics', description: 'Dips the colors into a soft, illuminated shadow.' },
  { id: 'halo', label: 'Halo', group: 'Light & optics', description: 'Builds a layered, multicolor halo around the pointer.' },
  { id: 'flashlight', label: 'Flashlight', group: 'Light & optics', description: 'Reveals a concentrated moving pool of color.' },
  { id: 'comet-trail', label: 'Comet trail', group: 'Trails & texture', description: 'Streams a bright tail behind fast pointer movement.' },
  { id: 'afterimage', label: 'Afterimage', group: 'Trails & texture', description: 'Leaves a soft, delayed afterimage in the field.' },
  { id: 'particle-stream', label: 'Particle stream', group: 'Trails & texture', description: 'Scatters animated particles along the motion path.' },
  { id: 'ribbon-trail', label: 'Ribbon trail', group: 'Trails & texture', description: 'Draws a flowing ribbon that follows pointer direction.' },
  { id: 'orbiting-dots', label: 'Orbiting dots', group: 'Trails & texture', description: 'Places moving color dots along a tiny orbital field.' },
  { id: 'ember-trail', label: 'Ember trail', group: 'Trails & texture', description: 'Leaves a flickering, warm multicolor wake.' },
  { id: 'starfall', label: 'Starfall', group: 'Trails & texture', description: 'Scatters sharp glints through the pointer wake.' },
  { id: 'paint-streak', label: 'Paint streak', group: 'Trails & texture', description: 'Smears the gradient like wet, flowing paint.' },
  { id: 'velocity-smear', label: 'Velocity smear', group: 'Trails & texture', description: 'Stretches the color field in the direction of motion.' },
  { id: 'echo-trail', label: 'Echo trail', group: 'Trails & texture', description: 'Repeats offset fading echoes behind the pointer.' },
] as const;

export type PointerMode = (typeof POINTER_MODES)[number]['id'];

export function pointerModeId(mode: PointerMode): number {
  const index = POINTER_MODES.findIndex(item => item.id === mode);
  return index < 0 ? 2 : index;
}

export function normalizePointerMode(value: unknown): PointerMode {
  return typeof value === 'string' && POINTER_MODES.some(item => item.id === value)
    ? value as PointerMode
    : 'swirl';
}
